#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include <random>

static inline QRectF cellRect(int x,int y,int c){ return QRectF(x*c, y*c, c, c); }

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // 두 장면을 각 뷰에 연결
    sceneAst = new QGraphicsScene(this);
    sceneDij = new QGraphicsScene(this);
    ui->Astar_map->setScene(sceneAst);
    ui->Dijkstra_map->setScene(sceneDij);
    ui->Astar_map->setRenderHint(QPainter::Antialiasing,false);
    ui->Dijkstra_map->setRenderHint(QPainter::Antialiasing,false);

    // 클릭 처리(두 뷰 공통)
    ui->Astar_map->viewport()->installEventFilter(this);
    ui->Dijkstra_map->viewport()->installEventFilter(this);
    ui->Astar_map->setMouseTracking(true);
    ui->Dijkstra_map->setMouseTracking(true);

    // 초기값
    ui->obstacle_percentage->setRange(0,100);
    ui->obstacle_percentage->setValue(30);
    ui->spinBox->setRange(5,100);
    ui->spinBox->setValue(grid.w);

    sx=0; sy=0; gx=grid.w-1; gy=grid.h-1;

    redrawBoth();
}

MainWindow::~MainWindow(){ delete ui; }

// ===== 페이지 전환 =====
void MainWindow::on_Map_Editing_clicked(){ ui->stackedWidget->setCurrentWidget(ui->Map_Editing_Page); }
void MainWindow::on_Map_Setting_clicked(){
    ui->stackedWidget->setCurrentWidget(ui->Map_Setting_Page);
    tool_ = Tool::Start;                                // ★ 기본값: 시작점 찍기
    statusBar()->showMessage("시작점 셀을 클릭하세요");
}
void MainWindow::on_Path_Search_clicked(){ ui->stackedWidget->setCurrentWidget(ui->Path_Search_Page); }

// ===== Map Editing =====
void MainWindow::on_generate_map_editing_page_clicked(){
    const int pct = ui->obstacle_percentage->value();
    std::mt19937 rng(std::random_device{}());
    std::uniform_int_distribution<> d(0,99);

    std::fill(grid.obs.begin(), grid.obs.end(), 0);
    for(int y=0;y<grid.h;y++)
        for(int x=0;x<grid.w;x++)
            if(d(rng)<pct) grid.obs[grid.id(x,y)] = 1;

    // 출발/도착은 항상 비우기
    grid.obs[grid.id(sx,sy)] = 0;
    grid.obs[grid.id(gx,gy)] = 0;

    redrawBoth();
}
void MainWindow::on_claer_map_editing_page_clicked(){
    std::fill(grid.obs.begin(), grid.obs.end(), 0);
    // 시작·도착 무효화
    sx = sy = gx = gy = -1;
    redrawBoth();
}

// ===== Map Setting =====
void MainWindow::on_apply_map_setting_page_clicked(){
    int n = ui->spinBox->value();     // n x n
    grid = Grid(n,n);
    sx=0; sy=0; gx=n-1; gy=n-1;
    redrawBoth();
}
void MainWindow::on_setStartBtn_clicked(){ tool_ = Tool::Start; statusBar()->showMessage("시작점 셀을 클릭"); }
void MainWindow::on_setGoalBtn_clicked() { tool_ = Tool::Goal;  statusBar()->showMessage("도착점 셀을 클릭"); }

// ===== 공통 그리기 =====
void MainWindow::redrawBoth(){ drawOne(sceneAst); drawOne(sceneDij); }
void MainWindow::drawOne(QGraphicsScene* sc){
    sc->clear();
    sc->setSceneRect(0,0, grid.w*cell, grid.h*cell);
    for(int y=0;y<grid.h;y++)
        for(int x=0;x<grid.w;x++){
            QColor fill = grid.blocked(x,y)? QColor(40,40,40) : QColor(255,255,255);
            sc->addRect(cellRect(x,y,cell), QPen(Qt::lightGray), QBrush(fill));
        }
    if(grid.in(sx,sy)) sc->addRect(cellRect(sx,sy,cell), QPen(Qt::green,2));
    if(grid.in(gx,gy)) sc->addRect(cellRect(gx,gy,cell), QPen(Qt::red,2));

}

// ===== 클릭 처리 =====
bool MainWindow::eventFilter(QObject* obj, QEvent* ev){
    if(ev->type()!=QEvent::MouseButtonPress) return false;

    // 어떤 뷰에서 클릭했는지 판별
    QGraphicsView* view=nullptr;
    if(obj==ui->Astar_map->viewport())          view=ui->Astar_map;
    else if(obj==ui->Dijkstra_map->viewport())  view=ui->Dijkstra_map;
    else return false;

    // 장면 좌표 → 셀 좌표
    auto* me = static_cast<QMouseEvent*>(ev);
    QPointF sp = view->mapToScene(me->pos());
    int x = int(sp.x())/cell, y = int(sp.y())/cell;
    if(!grid.in(x,y)) return true;

    // ★ Map_Setting에서만 동작: 시작/도착 설정. 장애물은 절대 변경 안 함
    // Map_Setting: 시작/도착 지정 + 자동 전환
    if(ui->stackedWidget->currentWidget()==ui->Map_Setting_Page){
        if(grid.blocked(x,y)) return true;

        if(tool_==Tool::Start){
            sx=x; sy=y;
            if(grid.in(sx,sy)) grid.obs[grid.id(sx,sy)]=0;
            tool_ = Tool::Goal;                           // ★ 자동 전환
            statusBar()->showMessage("도착점 셀을 클릭하세요");
        } else if(tool_==Tool::Goal){
            gx=x; gy=y;
            if(grid.in(gx,gy)) grid.obs[grid.id(gx,gy)]=0;
            tool_ = Tool::None;                           // ★ 완료 후 종료
            statusBar()->showMessage("시작/도착 설정 완료");
        }
        redrawBoth();
        return true;
    }


    // ★ 다른 페이지에서는 클릭 무시
    return false;
}
