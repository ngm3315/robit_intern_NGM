#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QEvent>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct Grid {
    int w=30, h=30;
    std::vector<unsigned char> obs;
    Grid(int W=30,int H=30):w(W),h(H),obs(W*H,0){}
    bool in(int x,int y) const { return 0<=x && x<w && 0<=y && y<h; }
    bool blocked(int x,int y) const { return obs[y*w+x]; }
    int  id(int x,int y) const { return y*w+x; }
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent=nullptr);
    ~MainWindow();

private slots:
    // 페이지 전환
    void on_Map_Editing_clicked();
    void on_Map_Setting_clicked();
    void on_Path_Search_clicked();

    // Map Editing
    void on_generate_map_editing_page_clicked();
    void on_claer_map_editing_page_clicked();

    // Map Setting
    void on_apply_map_setting_page_clicked();
    void on_setStartBtn_clicked();
    void on_setGoalBtn_clicked();

protected:
    bool eventFilter(QObject* obj, QEvent* ev) override;

private:
    Ui::MainWindow *ui=nullptr;

    // 공용 맵(양쪽 뷰 동기화)
    Grid grid{30,30};
    int sx=0, sy=0;               // start
    int gx=29, gy=29;             // goal

    // 두 장면
    QGraphicsScene *sceneAst=nullptr, *sceneDij=nullptr;
    int cell=22;

    enum class Tool { None, Start, Goal } tool_ = Tool::None;

    void redrawBoth();
    void drawOne(QGraphicsScene* sc);
};
#endif
